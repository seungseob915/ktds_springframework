package com.service;

public class DBService2 {

	public DBService2() {
		System.out.println("DBService2 생성자");
	}
	public String getInfo() {
		return "Hello";
	}
	
}
