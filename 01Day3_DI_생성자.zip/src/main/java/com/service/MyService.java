package com.service;

public class MyService {


	public String name;
	public int age;

	public MyService() {
	}

	// 생성자 주입
	public MyService(String name, int age) {
		this.name = name;
		this.age = age;
	}

	
	
	
}
