package com.service;

public class DBService {

	public DBService() {
		System.out.println("DBService 생성자");
	}
	
	public String getInfo() {
		return "Hello";
	}
}
